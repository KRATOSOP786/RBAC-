// src/App.js
import React from 'react';
import Portfolio from './Portfolio';

const App = () => {
  return (
    <div className="App">
      <Portfolio />
    </div>
  );
};

export default App;
